import React from 'react';
import Barcode from 'react-barcode';
import { InventoryItem } from '../types';
import { XMarkIcon } from './icons/XMarkIcon';

interface PrintBarcodeModalProps {
  item: InventoryItem;
  onClose: () => void;
}

const PrintBarcodeModal: React.FC<PrintBarcodeModalProps> = ({ item, onClose }) => {
  const handlePrint = () => {
    const printContents = document.getElementById('barcode-to-print')?.innerHTML;
    const originalContents = document.body.innerHTML;
    if (printContents) {
      document.body.innerHTML = printContents;
      window.print();
      document.body.innerHTML = originalContents;
      window.location.reload(); // Reload to restore the original state
    }
  };

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center">
      <div className="relative p-8 border w-auto shadow-lg rounded-md bg-white">
        <button onClick={onClose} className="absolute top-4 right-4 p-2">
          <XMarkIcon />
        </button>
        <div id="barcode-to-print" className="text-center">
          <h2 className="text-2xl font-bold mb-4">{item.description}</h2>
          <Barcode value={item.id} />
          <p className="mt-2">{item.id}</p>
        </div>
        <div className="flex justify-center mt-6">
          <button onClick={handlePrint} className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            Print
          </button>
        </div>
      </div>
    </div>
  );
};

export default PrintBarcodeModal;
